# Fábrica de Integrações — E-Catálogos

Este repositório contém o Harness operacional usado para construir, validar, testar, homologar e documentar integrações entre ERPs parceiros e ferramentas da E-Catálogos.

## Escopo atual

A primeira jornada operacional em construção é **Parceiros**.

A jornada de Clientes será criada posteriormente dentro da mesma fábrica, de forma separada, reutilizando contratos, adaptadores e integrações homologadas.

## Para uma nova IA/pessoa

Comece por:

```text
00-CONTEXTO-INICIAL-DO-PROJETO.md
```

Depois leia:

```text
AGENTS.md
parceiros/AGENTS.md
parceiros/00-GUIA-DE-EXECUCAO.md
parceiros/01-COMO-USAR-OS-COMANDOS.md
```

## Para o operador

Você não precisa criar/copiar/renomear pastas manualmente para executar a fábrica.

A interface esperada é:

```text
PROMPT + DOCUMENTAÇÃO + DADOS CONHECIDOS
                    ↓
                  CODEX
                    ↓
      CRIA/LOCALIZA A EXECUÇÃO
                    ↓
        EXECUTA E VALIDA A ETAPA
```

## Estado atual dos comandos

O primeiro comando está preparado para validação real:

```text
parceiros/comandos/01-APRESENTAR-E-ANALISAR-FERRAMENTA.md
```

Os comandos seguintes serão fechados e validados conforme a execução real da V1 avançar. Não devem ser tratados como existentes enquanto não estiverem presentes no repositório.

## Primeira execução

A primeira ferramenta será o **Força de Vendas**.

A ideia é executar o Passo 01 usando a documentação oficial, revisar o resultado e ajustar o Harness antes de avançar para as próximas etapas.
