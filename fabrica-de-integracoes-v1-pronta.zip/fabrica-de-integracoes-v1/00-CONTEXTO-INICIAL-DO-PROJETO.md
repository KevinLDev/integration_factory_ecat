# Contexto inicial — Fábrica de Integrações E-Catálogos

Este documento serve para contextualizar um novo ChatGPT, Codex ou pessoa que esteja entrando no projeto.

## Objetivo

Construir uma Fábrica de Integrações assistida por IA para padronizar e acelerar integrações entre ERPs parceiros e ferramentas da E-Catálogos.

As primeiras ferramentas consideradas são Força de Vendas, B2B e Lojas/Vestuário.

O primeiro caso real será o **Força de Vendas**.

## Princípio central

Quem define o contrato é a E-Catálogos.

```text
ERP <-> adaptador do ERP <-> contrato da ferramenta E-Catálogos
```

A fábrica deve descobrir como o ERP atende ao que a ferramenta E-Catálogos precisa, e não tentar integrar tudo que o ERP oferece.

## Operação

A fábrica será operada principalmente por VS Code/Cursor, Codex, terminal, arquivos Markdown, documentação de APIs e testes.

O operador fornece intenção, nomes, documentação, arquivos, credenciais e decisões humanas quando necessárias.

O Codex é responsável por criar e organizar a estrutura técnica da execução.

## Harness Engineering

O projeto usa princípios de Harness Engineering: contexto, regras, comandos, documentação, estado persistente, testes e feedback ficam no próprio repositório para que a execução não dependa da memória de um chat.

`AGENTS.md` é a porta de entrada do Harness, mas o Harness completo inclui os guias, comandos, fontes, testes, estado e validações.

## Escopo atual

A jornada operacional atual é **Parceiros**.

Clientes será uma jornada separada posteriormente dentro da mesma fábrica, reutilizando integrações e adaptadores homologados pela jornada de Parceiros.

## Regras essenciais

- E-Catálogos é a referência canônica.
- Bidirecionalidade é analisada por padrão para módulos aplicáveis.
- Não inventar endpoint, campo ou regra.
- Toda conclusão técnica deve possuir evidência.
- Não pular etapas.
- Não considerar etapa concluída apenas porque arquivos foram criados.
- A memória oficial é o repositório, não o chat.
- Implementações antigas do Pipedream são referência histórica, não arquitetura oficial.

## Primeira execução planejada

1. revisar o Harness;
2. executar o Passo 01 com a documentação oficial do Força de Vendas;
3. analisar o resultado;
4. corrigir eventuais lacunas do Harness;
5. somente então avançar para o cadastro/validação da ferramenta e etapas seguintes.

## Ao iniciar um novo chat

Leia, nesta ordem:

1. `00-CONTEXTO-INICIAL-DO-PROJETO.md`;
2. `README.md`;
3. `AGENTS.md`;
4. `parceiros/AGENTS.md`;
5. `parceiros/00-GUIA-DE-EXECUCAO.md`;
6. `parceiros/01-COMO-USAR-OS-COMANDOS.md`;
7. o comando da etapa atual.

Antes de propor alterações, resuma o que entendeu, aponte contradições e não modifique nada até receber autorização.
