# Guia de execução — Parceiros

## Para quem é este guia

Este guia foi escrito para uma pessoa conseguir operar a Fábrica de Integrações sem precisar conhecer a arquitetura, criar pastas manualmente ou montar estrutura de arquivos.

A interface do operador com a fábrica é simples:

```text
PROMPT + DADOS QUE VOCÊ CONHECE + DOCUMENTAÇÃO/ARQUIVOS
                         ↓
                       CODEX
                         ↓
         CRIA E ORGANIZA A EXECUÇÃO SOZINHO
```

## Regra número 1

**Não pule documentos.** Cada documento é um portão de qualidade. Só avance quando o Codex responder:

```text
STATUS DA ETAPA: CONCLUIDA
```

Se responder `PENDENTE`, forneça o que foi solicitado e execute **o mesmo comando novamente**.

Se responder `BLOQUEADA`, resolva o impedimento informado e repita a mesma etapa.

## O operador NÃO deve fazer

Não é responsabilidade do operador:

- criar pasta de execução;
- copiar modelo;
- colar modelo em outra pasta;
- renomear pasta;
- criar `ESTADO-DA-EXECUCAO.md`;
- criar arquivo de análise;
- criar estrutura de ferramenta ou ERP;
- decidir onde um artefato técnico deve ser salvo;
- preencher manualmente placeholders dentro dos comandos.

Tudo isso é responsabilidade do Codex conforme as regras do Harness.

## O operador deve fazer

O operador precisa somente:

1. identificar o cenário;
2. enviar o comando da etapa;
3. informar nomes básicos pedidos no prompt;
4. fornecer/apontar documentação e arquivos disponíveis;
5. fornecer informações extras que conhecer;
6. responder às pendências quando o Codex realmente não puder descobrir algo;
7. só avançar quando a etapa estiver `CONCLUIDA`.

## Jornada A — Nova ferramenta E-Catálogos

Use quando Força de Vendas, B2B, Lojas ou futura ferramenta ainda não estiver cadastrada e validada.

Ordem:

```text
01 APRESENTAR E ANALISAR FERRAMENTA
        ↓
02 CADASTRAR FERRAMENTA
        ↓
03 VALIDAR FERRAMENTA CADASTRADA
        ↓
04 GERAR COMANDOS ESPECÍFICOS DA FERRAMENTA
```

Para iniciar, o operador pode enviar algo tão simples quanto:

```text
Execute integralmente:
parceiros/comandos/01-APRESENTAR-E-ANALISAR-FERRAMENTA.md

Nova ferramenta: Força de Vendas
Objetivo: ferramenta de força de vendas da E-Catálogos
Documentação: <anexos ou caminhos disponíveis>
```

O Codex deve criar automaticamente a execução e todo o estado necessário.

## Jornada B — Novo ERP parceiro

Pré-requisito: a ferramenta E-Catálogos alvo deve ter concluído os passos 01–04.

Ordem:

```text
05 APRESENTAR E ANALISAR ERP PARCEIRO
        ↓
06 MAPEAR ERP X FERRAMENTA
        ↓
07 CRIAR BASE COMERCIAL DO ERP
        ↓
08 GERAR INTEGRAÇÃO BIDIRECIONAL
        ↓
09 TESTAR INTEGRAÇÃO POR MÓDULO
        ↓
10 HOMOLOGAR INTEGRAÇÃO COMPLETA
        ↓
11 GERAR DOCUMENTAÇÃO FINAL
```

Para iniciar um ERP parceiro:

```text
Execute integralmente:
parceiros/comandos/05-APRESENTAR-E-ANALISAR-ERP-PARCEIRO.md

Novo ERP parceiro: Linx
Ferramenta E-Catálogos: Força de Vendas
Documentação do ERP: <anexos ou caminhos disponíveis>
Informações adicionais: <se houver>
```

O Codex deve criar automaticamente a execução correspondente ao ERP + ferramenta.

## Como continuar uma execução

Nas etapas seguintes não é necessário informar caminho de pasta da execução.

Exemplo:

```text
Execute integralmente:
parceiros/comandos/06-MAPEAR-ERP-X-FERRAMENTA.md

ERP: Linx
Ferramenta: Força de Vendas
```

O Codex deve localizar sozinho a execução correta, ler o estado e os artefatos anteriores e continuar.

Se houver mais de uma execução que corresponda exatamente ao mesmo ERP + ferramenta e não for possível decidir com segurança qual usar, deve retornar `PENDENTE` e pedir apenas a identificação necessária.

## Memória persistente

A conversa do Codex não é a memória oficial da fábrica.

O Codex deve criar e manter automaticamente uma pasta de execução e, dentro dela, pelo menos:

```text
DADOS-DA-EXECUCAO.md
ESTADO-DA-EXECUCAO.md
referencias/
```

A estrutura exata pode evoluir pelo Harness, mas o operador não precisa criá-la.

`ESTADO-DA-EXECUCAO.md` deve informar:

- ferramenta;
- ERP quando aplicável;
- etapa atual;
- etapas concluídas;
- artefatos produzidos;
- pendências;
- bloqueios;
- próxima etapa permitida.

## Credenciais

Quando autenticação real for necessária, o operador pode fornecer as credenciais diretamente na solicitação ou por arquivo local indicado.

O Codex pode utilizá-las na execução e, se precisar persistir para reutilização local, deve criar automaticamente um arquivo de credenciais apropriado dentro da área da execução e mantê-lo fora do versionamento.

O operador não precisa criar `.env` manualmente.

Segredos não devem ser repetidos desnecessariamente em relatórios, documentação final, exemplos ou logs persistentes.

## Retorno obrigatório

Cada comando termina obrigatoriamente em um destes estados:

```text
STATUS DA ETAPA: CONCLUIDA
```

```text
STATUS DA ETAPA: PENDENTE
```

```text
STATUS DA ETAPA: BLOQUEADA
```

Somente `CONCLUIDA` libera a próxima etapa.
