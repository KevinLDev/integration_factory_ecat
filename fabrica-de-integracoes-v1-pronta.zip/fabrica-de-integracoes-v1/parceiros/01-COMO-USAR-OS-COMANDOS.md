# Como usar os comandos

## Conceito

Os documentos em `parceiros/comandos/` são prompts/regras fixas da fábrica.

**Você não edita esses arquivos.**

Você apenas diz ao Codex qual comando executar e fornece os dados conhecidos daquela execução.

## Exemplo — cadastrar nova ferramenta

Envie:

```text
Execute integralmente:
parceiros/comandos/01-APRESENTAR-E-ANALISAR-FERRAMENTA.md

Nova ferramenta: Força de Vendas
Objetivo: ferramenta de força de vendas da E-Catálogos
Documentação: Documentacao_API_Forca_de_Vendas.pdf
```

Se tiver Swagger/OpenAPI separado, exemplos ou regras adicionais, inclua também.

O Codex cria sozinho a estrutura persistente da execução.

## Exemplo — novo ERP parceiro

Envie:

```text
Execute integralmente:
parceiros/comandos/05-APRESENTAR-E-ANALISAR-ERP-PARCEIRO.md

Novo ERP parceiro: Bling
Ferramenta E-Catálogos: Força de Vendas
Documentação: <arquivos ou caminhos>
```

Se precisar testar autenticação, você pode também fornecer as credenciais necessárias. O Codex deve organizar o uso/persistência local conforme o Harness.

## Exemplo — próxima etapa

Quando o Codex terminar com:

```text
STATUS DA ETAPA: CONCLUIDA
```

envie:

```text
Execute integralmente:
parceiros/comandos/06-MAPEAR-ERP-X-FERRAMENTA.md

ERP: Bling
Ferramenta: Força de Vendas
```

Você não precisa informar a pasta onde o Codex salvou a execução. Ele deve localizá-la automaticamente.

## Quando fornecer arquivos

Você pode:

- anexar o arquivo;
- apontar um arquivo já existente no repositório;
- indicar uma pasta contendo documentação;
- informar uma URL quando o ambiente permitir acesso;
- fornecer Swagger/OpenAPI, PDF, exemplos, manuais e regras complementares.

O comando define o que precisa ser analisado; você apenas fornece o material que possui.

## Quando faltar informação

Não tente adivinhar.

Se o Codex puder descobrir pela documentação ou pelo ambiente, ele deve descobrir sozinho.

Se realmente depender de uma decisão/informação humana, ele termina como `PENDENTE` e informa exatamente o que precisa.

## O que nunca deve ser pedido ao operador

Durante o fluxo normal, o Codex não deve pedir ao operador para:

- criar uma pasta;
- copiar um modelo;
- renomear uma pasta;
- criar arquivos de estado;
- mover documentação para uma estrutura específica apenas para o comando funcionar;
- preencher placeholders dentro do `.md` de comando.

Se algum comando depender disso, o Harness deve ser corrigido.

## Modelos existentes no repositório

A pasta `parceiros/modelos/` existe como referência/esquema **para o próprio Codex**, não como uma tarefa manual para o operador.

Quando precisar de um modelo, o Codex deve lê-lo e criar a estrutura correspondente automaticamente.
