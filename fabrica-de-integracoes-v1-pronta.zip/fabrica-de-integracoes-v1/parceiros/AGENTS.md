# AGENTS.md — Jornada de Parceiros

Este arquivo complementa o `AGENTS.md` da raiz para qualquer trabalho realizado dentro de `parceiros/`.

Leia primeiro o `AGENTS.md` da raiz. Todas as regras globais continuam válidas.

## 1. Objetivo da jornada

A jornada de Parceiros transforma uma ferramenta E-Catálogos documentada e um ERP parceiro documentado em uma integração reutilizável, testada, homologada e documentada.

O fluxo conceitual é:

```text
Ferramenta E-Catálogos
        ↓
entender e cadastrar o contrato
        ↓
validar contra a fonte oficial
        ↓
ERP parceiro
        ↓
analisar capacidades
        ↓
mapear ERP x ferramenta
        ↓
criar base comercial de homologação
        ↓
gerar integração bidirecional
        ↓
testar módulos
        ↓
homologar ponta a ponta
        ↓
documentar integração reutilizável
```

## 2. Ordem obrigatória

A jornada deve ser executada por etapas e cada etapa funciona como portão de qualidade.

Ordem planejada:

```text
01 APRESENTAR E ANALISAR FERRAMENTA
02 CADASTRAR FERRAMENTA
03 VALIDAR FERRAMENTA CADASTRADA
04 GERAR CONHECIMENTO/COMANDOS ESPECÍFICOS DA FERRAMENTA
05 APRESENTAR E ANALISAR ERP PARCEIRO
06 MAPEAR ERP X FERRAMENTA
07 CRIAR BASE COMERCIAL DO ERP
08 GERAR INTEGRAÇÃO BIDIRECIONAL
09 TESTAR INTEGRAÇÃO POR MÓDULO
10 HOMOLOGAR INTEGRAÇÃO COMPLETA
11 GERAR DOCUMENTAÇÃO FINAL
```

Não pule etapa concluindo implicitamente trabalho que pertence a um comando posterior.

Enquanto um comando ainda não existir ou não estiver validado, registre isso como lacuna do Harness; não improvise um fluxo permanente silenciosamente.

## 3. Interface com o operador

O operador chama um comando e fornece o mínimo necessário para identificar a execução.

Exemplo:

```text
Execute integralmente:
parceiros/comandos/01-APRESENTAR-E-ANALISAR-FERRAMENTA.md

Nova ferramenta: Força de Vendas
Objetivo: ferramenta de força de vendas da E-Catálogos
Documentação: <arquivos/anexos/caminhos>
```

O operador não precisa informar a pasta de execução.

O agente deve:

1. localizar uma execução existente quando ela for inequívoca;
2. criar automaticamente uma execução quando a etapa inicial exigir;
3. registrar dados recebidos;
4. persistir estado;
5. organizar/referenciar documentação sem exigir trabalho de Explorer do operador;
6. retornar `PENDENTE` somente quando a informação necessária realmente não puder ser descoberta.

## 4. Ferramenta E-Catálogos primeiro

Antes de integrar qualquer ERP, a ferramenta E-Catálogos alvo precisa estar compreendida, cadastrada e validada.

O cadastro da ferramenta deve ser baseado em fonte oficial e registrar, quando aplicável:

- autenticação;
- ambientes;
- módulos/tags;
- endpoints e métodos;
- parâmetros;
- requests/responses;
- schemas;
- enums;
- paginação;
- erros;
- dependências;
- chaves externas/correlação;
- operações disponíveis;
- regras explícitas de negócio.

O cadastro não é considerado confiável até ser comparado novamente com a fonte oficial.

## 5. ERP parceiro

Ao receber um ERP parceiro, não implemente imediatamente.

Primeiro produza inventário técnico e depois mapeamento contra o contrato da ferramenta E-Catálogos.

Para cada capacidade relevante, identifique:

- endpoint/operação em ambos os lados;
- direção;
- campos de origem e destino;
- tipos;
- obrigatoriedade;
- transformação;
- dependências;
- chave de correlação;
- criação versus atualização;
- idempotência;
- prevenção de loop;
- limitações;
- evidência usada.

Sem evidência suficiente, registre `PENDENTE`.

## 6. Base comercial de homologação

Quando o ERP parceiro estiver vazio ou incompleto, crie apenas a base necessária para provar os contratos e cenários da ferramenta E-Catálogos.

Exemplos de entidades possíveis:

- clientes;
- produtos;
- categorias;
- marcas;
- cores;
- tamanhos;
- variantes;
- SKUs;
- filiais;
- representantes;
- tabelas de preço;
- preços;
- estoque;
- métodos/condições de pagamento;
- pedidos e status.

A lista final vem do contrato da ferramenta e do mapeamento aprovado. Não popule entidades apenas porque o ERP as possui.

Registre IDs e cenários criados para que os testes posteriores sejam reproduzíveis.

## 7. Bidirecionalidade

Todo módulo aplicável deve ser avaliado nas duas direções.

Para cada direção, responda explicitamente:

- como identificar alteração nova;
- como correlacionar registros;
- como decidir criar versus atualizar;
- como impedir duplicação;
- como impedir loop;
- qual sistema prevalece em conflito;
- como registrar falha parcial;
- como reprocessar com segurança.

Se uma operação não existir em uma das APIs, registre a limitação com evidência. Não simule suporte inexistente.

## 8. Testes obrigatórios

Os testes devem validar comportamento, não apenas status HTTP.

Quando aplicável, cubra:

- autenticação;
- leitura;
- criação;
- atualização;
- paginação;
- transformação;
- campos obrigatórios;
- dependências;
- correlação;
- duplicidade;
- idempotência;
- prevenção de loop;
- rate limit;
- retry/backoff;
- timeout;
- erro isolado;
- reprocessamento;
- dry-run;
- fluxo ponta a ponta.

Produtos devem considerar dependências como variante/SKU/preço/estoque quando existirem.

Pedidos e estoque devem validar explicitamente se o ERP reserva, baixa ou movimenta estoque automaticamente e como ocorre o estorno/cancelamento.

## 9. Evidências históricas

Ao analisar flows antigos do Pipedream, trate-os como fonte de cenários e regras reais, não como padrão arquitetural.

Se uma regra aparecer apenas no legado e não estiver comprovada na API/documentação atual, marque-a como hipótese/pendência até validar.

## 10. Estado da execução

Cada etapa deve atualizar `ESTADO-DA-EXECUCAO.md` com pelo menos:

- ferramenta;
- ERP quando aplicável;
- etapa atual;
- status;
- etapas concluídas;
- fontes consultadas;
- artefatos produzidos;
- validações realizadas;
- pendências;
- bloqueios;
- próxima etapa permitida.

A próxima etapa só pode ser liberada com `STATUS DA ETAPA: CONCLUIDA`.
