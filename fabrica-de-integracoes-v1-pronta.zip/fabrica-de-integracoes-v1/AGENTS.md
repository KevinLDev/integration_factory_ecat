# AGENTS.md — Constituição da Fábrica de Integrações E-Catálogos

Este arquivo contém as regras globais e permanentes para qualquer agente que trabalhe neste repositório.

Ele funciona como **porta de entrada do Harness**. Não é uma enciclopédia e não substitui os guias, comandos, documentação oficial das APIs nem os `AGENTS.md` mais específicos encontrados em subpastas.

## 1. Escopo físico autorizado

O agente está autorizado a trabalhar **somente dentro do repositório `fabrica-de-integracoes` atualmente aberto no workspace**.

### Permitido

- ler arquivos deste repositório;
- criar arquivos e diretórios dentro deste repositório;
- editar arquivos dentro deste repositório;
- executar comandos necessários ao projeto dentro deste workspace;
- utilizar Git para este repositório;
- consultar documentação e ambientes externos quando a etapa permitir e o operador fornecer/acesso estiver autorizado.

### Proibido sem autorização explícita do operador

- alterar arquivos fora deste repositório;
- alterar qualquer outro repositório da E-Catálogos;
- executar comandos Git em outro repositório;
- excluir ou renomear repositórios remotos;
- alterar configurações da organização GitHub;
- executar `git push --force` ou equivalentes;
- sobrescrever histórico Git;
- apagar branches remotas;
- fazer push direto na `main` quando houver fluxo de branch/PR definido;
- contornar proteções de branch ou regras do GitHub.

Se uma tarefa exigir alteração fora deste repositório, **pare e solicite autorização explícita**.

## 2. Hierarquia de instruções do repositório

Antes de modificar qualquer arquivo:

1. leia este `AGENTS.md` da raiz;
2. procure por outro `AGENTS.md` na árvore da pasta em que irá trabalhar;
3. leia o guia operacional correspondente;
4. leia o documento de comando da etapa;
5. leia o estado e os artefatos existentes da execução;
6. consulte as fontes técnicas originais necessárias.

Um `AGENTS.md` mais específico complementa as regras globais dentro do seu escopo. Ele não deve ser usado para enfraquecer regras de segurança, evidência ou isolamento definidas aqui.

## 3. Escopo funcional atual

A Fábrica será capaz de possuir jornadas separadas para **Parceiros** e **Clientes**, reutilizando contratos, adaptadores e conhecimento compartilhado.

Neste momento, a jornada operacional em construção e homologação é **Parceiros**.

Não misture comandos, execução ou regras específicas de Clientes na jornada atual de Parceiros. A jornada de Clientes será criada posteriormente como trilha própria dentro da mesma fábrica.

## 4. Conceitos que nunca podem ser confundidos

- **Ferramenta E-Catálogos:** produto/plataforma da E-Catálogos, como Força de Vendas, B2B ou Lojas/Vestuário.
- **ERP parceiro:** sistema externo cuja API será adaptada ao contrato da ferramenta E-Catálogos e homologada para reutilização.
- **Cliente:** empresa que posteriormente utilizará uma integração já homologada, com suas configurações e particularidades.

## 5. Autoridade do contrato

A ferramenta E-Catálogos é a referência canônica.

```text
ERP <-> adaptador do ERP <-> contrato da ferramenta E-Catálogos
```

A pergunta principal não é "como integrar tudo que o ERP possui?".

A pergunta é:

> "O que a ferramenta E-Catálogos precisa e como o ERP consegue atender a esse contrato?"

Não altere contratos compartilhados da E-Catálogos apenas para "fazer caber" um ERP sem decisão explícita, registrada e aprovada.

## 6. Hierarquia das fontes técnicas

Ao concluir fatos técnicos, priorize a seguinte ordem:

1. documentação oficial atual da ferramenta/ERP e OpenAPI/Swagger fornecido;
2. evidência obtida do ambiente/API autorizado;
3. testes reproduzíveis executados pela fábrica;
4. decisões de negócio explicitamente registradas e aprovadas;
5. documentação gerada pela própria fábrica;
6. implementações históricas/legadas, apenas como referência.

Nunca use documentação gerada pela fábrica como única prova para validar outro artefato gerado pela própria fábrica quando a fonte original estiver disponível.

## 7. Implementações históricas

Flows, steps e códigos antigos — incluindo integrações Pipedream entre Bling e Força de Vendas — são **referência histórica**, não arquitetura oficial.

Eles podem ser usados para identificar:

- regras de negócio reais;
- problemas já encontrados;
- dependências;
- paginação;
- retry/rate limit;
- correlação;
- SKU/variante/pack;
- estoque, reserva, baixa e estorno;
- criação versus atualização;
- status e campos personalizados.

Não copie automaticamente sua arquitetura, organização, dependência do Pipedream ou decisões específicas como padrão genérico da fábrica.

## 8. Regras técnicas permanentes

1. Não invente endpoints, campos, enums, relacionamentos, autenticação, limites ou regras comerciais.
2. Toda conclusão técnica relevante deve ser rastreável à documentação original, ambiente real autorizado ou evidência de teste.
3. Toda suposição não comprovada deve virar **PENDÊNCIA**.
4. Todo módulo aplicável deve ser analisado nas duas direções: ERP -> ferramenta e ferramenta -> ERP.
5. Bidirecionalidade não significa que toda operação existe. Use `NAO_SUPORTADO_PELA_API` quando houver evidência de limitação.
6. Para fluxos bidirecionais, documente chave de correlação, idempotência, prevenção de loop, origem da alteração e política de conflito.
7. Antes de implementar integração, produza mapeamento ERP x ferramenta com evidências.
8. Diferencie sucesso, ignorado, pendência, bloqueio e erro. Não esconda falhas para homologar.
9. Teste módulo isolado antes do end-to-end.
10. Verifique explicitamente estoque, reserva, baixa, estorno e cancelamento para evitar dupla movimentação.
11. Nunca confirme integração na origem antes de existir confirmação válida no destino quando o fluxo depender dessa garantia.
12. Prefira TypeScript estrito e componentes compartilhados para HTTP, autenticação, paginação, retry/backoff, rate limit, normalização, logs e erros quando a fase de implementação começar.

## 9. Credenciais e segredos

Credenciais reais podem ser fornecidas ao agente quando forem necessárias para o ambiente autorizado.

O agente pode utilizar usuário, senha, token, API key, client id, client secret, refresh token e outros segredos necessários à execução.

Quando precisar persistir localmente, deve criar automaticamente arquivo apropriado, como:

```text
credenciais-erp.env
credenciais-ferramenta.env
```

Regras:

- o operador não precisa criar esses arquivos manualmente;
- nunca mover segredos para arquivos versionados;
- nunca copiar valores secretos para código-fonte;
- não reproduzir valores completos em relatórios, documentação final, exemplos ou logs persistentes;
- não repetir valores completos na resposta ao operador sem necessidade explícita;
- respeitar o `.gitignore`.

## 10. Operação orientada por comandos

O operador fornece intenção, nomes, arquivos, documentação e dados conhecidos.

O operador **não deve precisar**:

- criar pasta de execução;
- copiar modelos;
- renomear pastas;
- criar arquivos de estado;
- organizar referências manualmente apenas para o comando funcionar;
- preencher placeholders dentro dos comandos.

O agente deve criar/localizar automaticamente a execução e organizar os artefatos necessários dentro do repositório.

## 11. Memória persistente

A memória oficial da fábrica não é o chat.

Toda informação necessária à continuidade deve ser persistida em arquivos, contratos, relatórios, configurações, testes ou evidências dentro do repositório.

Cada execução deve possuir, no mínimo, quando aplicável:

```text
DADOS-DA-EXECUCAO.md
ESTADO-DA-EXECUCAO.md
```

Se uma nova sessão do Codex começar, ela deve conseguir continuar o trabalho lendo o repositório.

## 12. Git e alterações

Antes de alterações relevantes:

- confirme que o diretório atual pertence a este repositório;
- confira a branch atual;
- preserve mudanças existentes que não façam parte da tarefa;
- não faça alterações destrutivas para "limpar" o workspace;
- não use `reset --hard`, force push ou comandos equivalentes sem autorização explícita.

Quando o fluxo Git da fábrica estiver configurado, trabalhe em branch própria e utilize Pull Request para integrar alterações à `main`.

## 13. Retorno e qualidade

Cada comando define seus critérios de aceite e formato de retorno.

Use somente:

- `CONCLUIDA`;
- `PENDENTE`;
- `BLOQUEADA`.

Nunca marque `CONCLUIDA` apenas porque arquivos foram criados.

Uma etapa só está concluída quando os critérios de aceite foram realmente verificados com evidência.
